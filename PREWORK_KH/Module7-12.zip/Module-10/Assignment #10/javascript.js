// document.getElementById('contents'); --> returns a HTML DOM Object
// var contents = $('#contents');  --> returns a jQuery Object

// In jQuery, to get the same result as document.getElementById, you can access the jQuery Object and get the first element in the object

// var contents = $('#contents')[0]; --> returns a HTML DOM Object


$("#button1")[0].onclick = function() {
    $("#box")[0].style.height = "200";
};
// document.getElementById("button2").onclick = function() {
//     document.getElementById("box").style.height= "200";
// };



$("#button2")[0].onclick = function() {
    $("#box")[0].style.backgroundColor = "blue";
}
// document.getElementById("button2").onclick = function() {
//     document.getElementById("box").style.backgroundColor = "blue";
// }



$("#button3")[0].onclick = function() {
    $("#box")[0].style.opacity = "0.5";
}
// document.getElementById("button3").onclick = function() {
//      document.getElementById("box").style.opacity = "0.5";
// }



$("#button4")[0].onclick = function() {
    $("#box")[0].style.height = "150";
    $("#box")[0].style.backgroundColor = "orange";
    $("#box")[0].style.opacity = "1";
    $("#box")[0].style.width = "150";
}
// document.getElementById("button3").onclick = function() {
//      document.getElementById("box").style.height = "150";
//      document.getElementById("box").style.backgroundColor = "orange";
//      document.getElementById("box").style.opacity = "1";
// }


$("#button5")[0].onclick = function() {
    var currentWidth = $("#box")[0].style.width.replace('px', '')
    var num = parseInt(currentWidth, 10)
    $("#box")[0].style.width = `${num + 10}px`
}

$("#button6")[0].onclick = function() {
    var currentRight = $("#box")[0].style.marginLeft.replace('px', '')
    var right = parseInt(currentRight, 10)
    return $("#box")[0].style.marginLeft = `${left + 10}px`
}